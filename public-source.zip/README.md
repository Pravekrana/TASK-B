# Local warranty review assistant - source-only demonstration

Private assignment data and model artifacts are intentionally excluded.
Use Python 3.12. No paid API key is needed.

    python -m venv .venv
    # Activate .venv using your platform standard command
    python -m pip install -r requirements.txt
    python demo_setup.py
    python app.py

Open http://127.0.0.1:8000. Demo data, IDs and costs are synthetic.
POST /predict returns a risk score, readable reasons and shadow-mode guidance.
Missing artifacts give a polite 503; GET /health reports readiness.
Never automatically reject claims. This is a local development service without
production authentication or global review-queue enforcement.

The final algorithm is hierarchical empirical Bayes over recent investigation
outcomes, partner and amount band. Risk associations are not causal findings.
CatBoost experiments are included as an alternative, not an endorsement.
For private reproduction, add only authorized data/reference artifacts, replace
synthetic cost constants with approved policy settings, and run the training scripts.
Never commit raw claims, trained operational parameters, reference data or results.
